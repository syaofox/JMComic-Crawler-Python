from requests import get, post


class Postman:

    def __init__(self, kwargs) -> None:
        self.meta_data = kwargs

    def merge_kwargs(self, kwargs):
        """
        把 kwargs 合并到 self.meta_data.copy()
        """
        ret = self.meta_data.copy()
        for k, v in kwargs.items():
            ret[k] = v
        return ret

    def get(self, url, **kwargs):
        kwargs = self.merge_kwargs(kwargs)
        return get(url, **kwargs)

    def post(self, url, **kwargs):
        kwargs = self.merge_kwargs(kwargs)
        return post(url, **kwargs)

    def copy(self):
        return Postman(self.meta_data.copy())

    def __getattr__(self, item):
        return self.meta_data[item]

    @classmethod
    def create(cls, **kwargs):
        return Postman(kwargs)


class FixUrlPostman(Postman):

    def __init__(self, fix_url, postman: Postman):
        super().__init__(postman.meta_data.copy())
        self.fix_url = fix_url

    def get(self, url=None, **kwargs):
        return super().get(url or self.fix_url, **kwargs)

    def post(self, url=None, **kwargs):
        return super().post(url or self.fix_url, **kwargs)
