# _ocr = None
#
#
# def verify_code(img):
#     import ddddocr
#     global _ocr
#     if _ocr is None:
#         _ocr = ddddocr.DdddOcr(use_gpu=True, show_ad=False)
#
#     return _ocr.classification(img=img)
