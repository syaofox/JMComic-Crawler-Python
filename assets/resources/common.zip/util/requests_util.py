from requests import Response


class ProxyBuilder:
    proxy_protocols = ['https', 'http']
    addr_f = 'http://{}:{}'

    @classmethod
    def build_proxy(cls, address):
        proxies = {protocol: address for protocol in cls.proxy_protocols}
        return proxies

    @classmethod
    def clash_proxy(cls, ip='127.0.0.1', port='7890'):
        return cls.build_proxy(cls.addr_f.format(ip, port))

    @classmethod
    def v2Ray_proxy(cls, ip='127.0.0.1', port='10809'):
        return cls.build_proxy(cls.addr_f.format(ip, port))


def save_resp_content(resp: Response, filepath: str):
    from .file_util import mkdir_if_not_exists, of_dir_name
    mkdir_if_not_exists(of_dir_name(filepath))
    with open(filepath, 'wb') as f:
        f.write(resp.content)


def set_global_proxy(status='off'):
    """
    全局性的关闭或者启用系统代理。
    测试时发现，如果设置了系统代理，在访问 https 网站时发生错误 requests.exceptions.ProxyError
    原因是 SSL: self._sslobj.do_handshake() -> OSError: [Errno 0] Error
    进一步，是因为 urllib3 1.26.0 以上版本支持 https协议，但是代理软件不支持，导致连接错误。
    所以使用 { 'https': 'http://127.0.0.1:1080' }，http的协议访问 https 的网址（本地通信），即可解决。
    或者在 requests.get 函数中增加 proxies={'https': None} 参数来解决，但每次访问都需加这个参数，太麻烦，
    此处通过修改 requests 库中的 get_environ_proxies 函数的方法来全局性地关闭系统代理，或者仅关闭 https 的代理。
    参数：
    status - 'off', 关闭系统代理；
    'on', 打开系统代理；
    'toggle', 切换关闭或者打开状态；
    注意：仅影响本 Python程序的 requests包，不影响其他 Python程序，
    不影响 Windows系统的代理设置，也不影响浏览器的代理设置。
    """
    from requests import sessions, utils
    init_func = sessions.get_environ_proxies
    if status == 'off':
        # 关闭系统代理
        if init_func.__name__ == '<lambda>':
            # 已经替换了原始函数，即已经是关闭状态，无需设置
            return
        # 修改函数，也可以是 lambda *x, **y: {'https': None}
        sessions.get_environ_proxies = lambda *x, **y: {}
    elif status == 'on':
        # 打开系统代理，如果设置了代理的话
        # 对高版本的 urllib3(>1.26.0) 打补丁，修正 https代理 BUG: OSError: [Errno 0] Error
        # noinspection PyUnresolvedReferences
        proxies = utils.getproxies()
        if 'https' in proxies:
            proxies['https'] = proxies.get('http')  # None 或者 'http://127.0.0.1:1080'
        sessions.get_environ_proxies = lambda *x, **y: proxies
        sessions.get_environ_proxies.__name__ = 'get_environ_proxies'
    else:
        # 切换开关状态
        if init_func.__name__ == '<lambda>':
            # 已经是关闭状态
            set_global_proxy('on')
        else:
            # 已经是打开状态
            set_global_proxy('off')


def print_resp_json(resp: Response, indent=2):
    import json
    json_str = json.dumps(resp.json(), indent=indent)
    from .sys_util import parse_unicode_escape_text
    print(parse_unicode_escape_text(json_str))