from common import Any, Callable, Generator


class DictModel:
    def __init__(self, data: dict):
        if data is None:
            raise AssertionError(f"{self.__class__} __init__ parameter 'data' mustn't be None")

        for k, v in data.items():
            if k is None:
                continue
            if isinstance(v, (list, tuple)):
                setattr(self, k, [DictModel(e) if isinstance(e, dict) else e for e in v])
            else:
                setattr(self, k, DictModel(v) if isinstance(v, dict) else v)


def dict_2_obj(d: dict):
    return DictModel(d)


def accpet_json(fp, accept_v: Callable[[Any], None] = None, accpet_k: Callable[[str], None] = None):
    def __accept_json_keys_values(data):
        if isinstance(data, list):
            for each in data:
                __accept_json_keys_values(each)

        elif isinstance(data, dict):
            for k, v in data.items():
                if accpet_k is not None:
                    accpet_k(k)
                __accept_json_keys_values(v)
        else:
            if accept_v is not None:
                accept_v(data)

    import json
    data = json.load(fp)

    if accpet_k is not None or accept_v is not None:
        __accept_json_keys_values(data)

    return data


def keys_of_json(data) -> Generator:
    if isinstance(data, list):
        for each in data:
            keys_of_json(each)

    elif isinstance(data, dict):
        for k, v in data.items():
            yield k
            keys_of_json(v)


def values_of_json(data) -> Generator:
    if isinstance(data, list):
        for each in data:
            yield from values_of_json(each)

    elif isinstance(data, dict):
        for v in data.values():
            yield from values_of_json(v)

    else:
        yield data


def read_json(filepath, encoding='utf-8'):
    from .file_util import file_not_exists
    if file_not_exists(filepath):
        raise AssertionError(f"不存在的json文件路径：{filepath}")

    import json
    with open(filepath, 'r', encoding=encoding) as f:
        return json.load(f)
