import os

from common import List, Callable, Optional

from .assert_util import any_match


def fix_filepath(filepath: str, is_dir=True) -> str:
    filepath = ensure_legal_fn_for_win(filepath.replace("\\", '/').replace("//", '/'))

    if is_dir is not True:
        return filepath
    else:
        return filepath if filepath[-1] == '/' else filepath + '/'


def fix_suffix(suffix: str) -> str:
    """
    保证suffix以"."开头，如 .png
    """
    return suffix if suffix[0] == '.' else f'.{suffix}'


def mkdir_if_not_exists(dirpath: str):
    if not os.path.exists(dirpath):
        os.makedirs(dirpath, exist_ok=True)


def file_exists(filepath: str) -> bool:
    return os.path.exists(filepath)


def file_not_exists(filepath: str) -> bool:
    return not os.path.exists(filepath)


def dir_file_split_index(filepath):
    return max(filepath.rfind("/"), filepath.rfind("\\"))


_win_forbid_char = [char for char in '\\/:*?"<>|']


def ensure_legal_fn_for_win(filepath: str, attr_char='_', is_path=True) -> str:
    filename = of_file_name(filepath) if is_path else filepath
    if not any_match(filename, _win_forbid_char):
        return filepath

    for char in _win_forbid_char:
        if char in filename:
            filename = filename.replace(char, attr_char)

    return filename


def of_file_name(filepath: str, trim_suffix=False) -> str:
    if trim_suffix is True:
        filepath = change_file_suffix(filepath, '')

    return filepath[dir_file_split_index(filepath) + 1::]


def of_file_suffix(filepath: str, trim_comma=False) -> str:
    return filepath[filepath.rfind(".") + trim_comma:]


def change_file_name(filepath: str, new_name: str) -> str:
    index = dir_file_split_index(filepath)
    return filepath[:index] + new_name


def change_file_suffix(filepath: str, new_suffix: str) -> str:
    if new_suffix == '':
        return filepath[:filepath.rfind(".")]

    return filepath[:filepath.rfind(".") + (new_suffix[0] != '.')] + new_suffix


def of_dir_name(filepath):
    return os.path.dirname(filepath)


def create_file(filepath: str):
    f = open(filepath, 'w')
    f.close()


def files_of_dir(abs_dir_path: str) -> List[str]:
    abs_dir_path = fix_filepath(abs_dir_path)
    return [f'{abs_dir_path}{f_or_d}' for f_or_d in os.listdir(abs_dir_path)]


def accept_files_of_dir(abs_dir_path: str, acceptor: Callable[[str, str, int], None]):
    abs_dir_path = fix_filepath(abs_dir_path)
    for index, filename in enumerate(os.listdir(abs_dir_path)):
        acceptor(f'{abs_dir_path}{filename}', filename, index)


def backup_dir(dirpath: str,
               zippath: str,
               zfile=None,
               prefix: Optional[str] = None,
               acceptor: Optional[Callable[[str], bool]]=None,
               ):
    if zfile is None:
        import zipfile
        zfile = zipfile.ZipFile(zippath, 'w')

    files = files_of_dir(dirpath)

    for f in files:
        file_name = of_file_name(f)

        if prefix is not None:
            file_name = f'{prefix}/{file_name}'

        if os.path.isdir(f):
            zfile.mkdir(file_name)
            backup_dir(f, zippath, zfile, prefix=file_name)
            continue

        if acceptor is None or acceptor(f) is True:
            zfile.write(f, file_name)

    return files


def read_text(filepath, encoding='utf-8') -> str:
    with open(filepath, 'r', encoding=encoding) as f:
        return f.read()


def write_text(filepath, content, encoding='utf-8'):
    with open(filepath, 'w', encoding=encoding) as f:
        f.write(content)
