from common import requests, Response, Callable, sleep

from .util import copy_obj


# 已过时，不建议使用此文件

class HttpHandler:
    proxies = None

    def __init__(self, **kwargs):
        self.headers = copy_obj(kwargs.get('headers', None))
        self.cookies = copy_obj(kwargs.get('cookies', None))
        self.timeout = kwargs.get('timeout', 3)
        self.failed_retry_interval = kwargs.get('failed_retry_interval', 3)

    def get(self,
            url,
            headers=None,
            cookies=None,
            timeout=None,
            failed_retry_interval=None,
            anonymous=False,
            **kwargs
            ) -> Response:
        raise NotImplementedError

    def post(self,
             url,
             headers=None,
             cookies=None,
             timeout=None,
             failed_retry_interval=None,
             anonymous=False,
             **kwargs
             ) -> Response:
        raise NotImplementedError

    def copy(self) -> 'HttpHandler':
        raise NotImplementedError


class HttpHandlerImpl(HttpHandler):

    def get(self,
            url,
            headers=None,
            cookies=None,
            timeout=None,
            failed_retry_interval=None,
            anonymous=False,
            **kwargs
            ):
        headers, cookies, failed_retry_interval, timeout = self.__of_default(headers,
                                                                             cookies,
                                                                             failed_retry_interval,
                                                                             timeout,
                                                                             anonymous)

        return self.do_http(failed_retry_interval, f"get局部重试: {url}",
                            lambda: requests.get(url,
                                                 headers=headers,
                                                 cookies=cookies,
                                                 timeout=timeout,
                                                 proxies=self.proxies,
                                                 **kwargs)
                            )

    def post(self,
             url,
             headers=None,
             cookies=None,
             failed_retry_interval=None,
             timeout=None,
             anonymous=False,
             **kwargs
             ):
        headers, cookies, failed_retry_interval, timeout = self.__of_default(headers,
                                                                             cookies,
                                                                             failed_retry_interval,
                                                                             timeout,
                                                                             anonymous)

        return self.do_http(failed_retry_interval, f"Post局部重试: {url}",
                            lambda: requests.post(url,
                                                  headers=headers,
                                                  cookies=cookies,
                                                  timeout=timeout,
                                                  proxies=self.__class__.proxies,
                                                  **kwargs)
                            )

    def __of_default(self, headers, cookies, failed_retry_interval, timeout, anonymous=False):
        if anonymous is False:
            if headers is None:
                headers = self.headers
            if cookies is None:
                cookies = self.cookies
        if failed_retry_interval is None:
            failed_retry_interval = self.failed_retry_interval
        if timeout is None:
            timeout = self.timeout

        return headers, cookies, failed_retry_interval, timeout

    def copy(self):
        return HttpHandlerImpl(headers=self.headers,
                               cookies=self.cookies,
                               timeout=self.timeout,
                               failed_retry_interval=self.failed_retry_interval)

    @staticmethod
    def do_http(failed_retry_interval: int,
                error_msg: str,
                runnable: Callable[[], Response]) -> Response:
        while True:
            try:
                return runnable()
            except requests.RequestException as e:
                print(f"{error_msg}\n{e}\n")
            sleep(failed_retry_interval)
